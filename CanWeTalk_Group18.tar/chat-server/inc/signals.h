#ifndef SIGNALS_H
#define SIGNALS_H

#include "main.h"

// Function prototypes
void handleSignal(int sig);

#endif /* SIGNALS_H */